import { Component, OnInit } from '@angular/core';
import { FlightService } from '../flight.service';

@Component({
  selector: 'app-addflight',
  templateUrl: './addflight.component.html',
  styleUrls: ['./addflight.component.css']
})
export class AddflightComponent implements OnInit {

  data: any = {};

  constructor(private flightService: FlightService) { }

  ngOnInit(): void {
  }

  addFlight() {
    
    this.flightService.addFlight(this.data).subscribe((res: any) => {
      alert("Flight added successfully");
    },
    (error) => {
      alert("Flight ");
    })
  }

}
